var indexSectionsWithContent =
{
  0: "acdeioprstwx",
  1: "cdp",
  2: "cdpx",
  3: "acdeiorstw",
  4: "s",
  5: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "related"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Amis"
};

