var searchData=
[
  ['options',['options',['../class_principal.html#a1ceddb8574161ad89af39766690604fd',1,'Principal']]]
];
