var searchData=
[
  ['transactionauto',['transactionAuto',['../class_principal.html#a1d8a6a36867ea0e74d0451d72d95f94a',1,'Principal']]]
];
